import React, { useState, useCallback } from 'react';
import { useDropzone } from 'react-dropzone';
import axios from 'axios';
import './FileUpload.css';

const API_URL = 'http://localhost:8000';

function FileUpload({ onUploadSuccess }) {
  const [uploading, setUploading] = useState(false);
  const [error, setError] = useState(null);
  const [selectedFiles, setSelectedFiles] = useState([]);
  const [settings, setSettings] = useState({
    embeddingModel: 'text-embedding-3-small',
    chunkSize: 1000,
    chunkOverlap: 200
  });

  const onDrop = useCallback((acceptedFiles) => {
    setSelectedFiles(acceptedFiles);
    setError(null);
  }, []);

  const { getRootProps, getInputProps, isDragActive } = useDropzone({
    onDrop,
    accept: {
      'application/pdf': ['.pdf'],
      'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet': ['.xlsx'],
      'application/vnd.ms-excel': ['.xls']
    },
    multiple: true
  });

  const handleUpload = async () => {
    if (selectedFiles.length === 0) {
      setError('Please select at least one file');
      return;
    }

    setUploading(true);
    setError(null);

    const formData = new FormData();
    selectedFiles.forEach(file => {
      formData.append('files', file);
    });
    formData.append('embedding_model', settings.embeddingModel);
    formData.append('chunk_size', settings.chunkSize);
    formData.append('chunk_overlap', settings.chunkOverlap);

    try {
      const response = await axios.post(`${API_URL}/upload`, formData, {
        headers: {
          'Content-Type': 'multipart/form-data'
        }
      });
      onUploadSuccess(response.data.info);
    } catch (err) {
      setError(err.response?.data?.detail || 'Failed to upload files');
    } finally {
      setUploading(false);
    }
  };

  return (
    <div className="file-upload-container">
      <div className="upload-card">
        <h2>Upload Documents</h2>
        <p className="subtitle">Upload PDF or Excel files to get started</p>

        <div {...getRootProps()} className={`dropzone ${isDragActive ? 'active' : ''}`}>
          <input {...getInputProps()} />
          <div className="dropzone-content">
            <svg className="upload-icon" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M7 16a4 4 0 01-.88-7.903A5 5 0 1115.9 6L16 6a5 5 0 011 9.9M15 13l-3-3m0 0l-3 3m3-3v12" />
            </svg>
            {isDragActive ? (
              <p>Drop the files here...</p>
            ) : (
              <>
                <p>Drag & drop files here, or click to select</p>
                <p className="file-types">PDF, Excel (.xlsx, .xls)</p>
              </>
            )}
          </div>
        </div>

        {selectedFiles.length > 0 && (
          <div className="selected-files">
            <h3>Selected Files:</h3>
            <ul>
              {selectedFiles.map((file, index) => (
                <li key={index}>
                  <span>{file.name}</span>
                  <span className="file-size">({(file.size / 1024).toFixed(2)} KB)</span>
                </li>
              ))}
            </ul>
          </div>
        )}

        <div className="upload-settings">
          <h3>Processing Settings</h3>
          
          <div className="setting-row">
            <label>Embedding Model:</label>
            <select value={settings.embeddingModel} onChange={(e) => setSettings({...settings, embeddingModel: e.target.value})}>
              <option value="text-embedding-3-small">Small (Faster)</option>
              <option value="text-embedding-3-large">Large (Better)</option>
            </select>
          </div>

          <div className="setting-row">
            <label>Chunk Size: {settings.chunkSize}</label>
            <input 
              type="range" 
              min="500" 
              max="2000" 
              step="100"
              value={settings.chunkSize} 
              onChange={(e) => setSettings({...settings, chunkSize: parseInt(e.target.value)})}
            />
          </div>

          <div className="setting-row">
            <label>Chunk Overlap: {settings.chunkOverlap}</label>
            <input 
              type="range" 
              min="0" 
              max="500" 
              step="50"
              value={settings.chunkOverlap} 
              onChange={(e) => setSettings({...settings, chunkOverlap: parseInt(e.target.value)})}
            />
          </div>
        </div>

        {error && <div className="error-message">{error}</div>}

        <button
          className="upload-button"
          onClick={handleUpload}
          disabled={uploading || selectedFiles.length === 0}
        >
          {uploading ? 'Uploading...' : 'Upload & Process'}
        </button>
      </div>
    </div>
  );
}

export default FileUpload;
