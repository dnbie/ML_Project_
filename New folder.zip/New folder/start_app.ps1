Write-Host "=== Starting Document Intelligence Assistant ===" -ForegroundColor Cyan
Write-Host ""

$backendPath = "backend"
$frontendPath = "frontend"

Write-Host "Starting Backend Server..." -ForegroundColor Yellow
Start-Process powershell -ArgumentList "-NoExit", "-Command", "cd '$PWD\$backendPath'; .\venv\Scripts\Activate.ps1; python app.py"

Start-Sleep -Seconds 3

Write-Host "Starting Frontend..." -ForegroundColor Yellow
Start-Process powershell -ArgumentList "-NoExit", "-Command", "cd '$PWD\$frontendPath'; npm start"

Write-Host ""
Write-Host "=== Application Starting ===" -ForegroundColor Green
Write-Host "Backend: http://localhost:8000" -ForegroundColor White
Write-Host "Frontend: http://localhost:3000" -ForegroundColor White
Write-Host ""
Write-Host "Two terminal windows will open. Close them to stop the application." -ForegroundColor Yellow
